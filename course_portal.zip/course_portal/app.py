from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import uuid
from models.user import User
from models.course import Course


app = Flask(__name__)
app.secret_key = 'my_secret_key' 

USERS_FILE = 'data/users.json'
COURSES_FILE = 'data/courses.json'
STUDENT_COURSES_FILE = 'data/student_courses.json'



def read_users():
    try:
        with open(USERS_FILE, 'r', encoding='utf-8') as f:
            return [User.from_dict(u) for u in json.load(f)]
    except FileNotFoundError:
        return []

def save_users(users):
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump([u.to_dict() for u in users], f, ensure_ascii=False, indent=4)

def read_courses():
    try:
        with open(COURSES_FILE, 'r', encoding='utf-8') as f:
            return [Course.from_dict(c) for c in json.load(f)]
    except FileNotFoundError:
        return []

def save_courses(courses):
    """ذخیره لیست دوره‌ها"""
    with open(COURSES_FILE, 'w', encoding='utf-8') as f:
        json.dump([c.to_dict() for c in courses], f, ensure_ascii=False, indent=4)

def read_student_courses():
    """خواندن ثبت‌نام‌های دانشجویان"""
    try:
        with open(STUDENT_COURSES_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

def save_student_courses(student_courses):
    """ذخیره ثبت‌نام‌های دانشجویان"""
    with open(STUDENT_COURSES_FILE, 'w', encoding='utf-8') as f:
        json.dump(student_courses, f, ensure_ascii=False, indent=4)

# -------------------------------
# 🏠 صفحه اصلی
# -------------------------------
@app.route('/')
def index():
    if 'username' in session:
        # انتقال به داشبورد مناسب
        if session['role'] == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('student_dashboard'))
    return render_template('index.html')

# -------------------------------
# 👤 ثبت‌نام کاربر
# -------------------------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        role = request.form['role']

        users = read_users()
        if any(u.username == username for u in users):
            return render_template('register.html', error="⚠️ این نام کاربری قبلاً استفاده شده.")

        new_user = User(username, password, role)
        users.append(new_user)
        save_users(users)

        flash("✅ ثبت‌نام موفقیت‌آمیز بود، حالا وارد شوید.", "success")
        return redirect(url_for('login'))
    return render_template('register.html')

# -------------------------------
# 🔑 ورود کاربر
# -------------------------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']

        users = read_users()
        user = next((u for u in users if u.username == username and u.password == password), None)

        if user:
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for('admin_dashboard') if user.role == 'admin' else url_for('student_dashboard'))
        else:
            return render_template('login.html', error="❌ نام کاربری یا رمز اشتباه است.")
    return render_template('login.html')

# -------------------------------
# 📋 داشبورد مدیر
# -------------------------------
@app.route('/admin/dashboard')
def admin_dashboard():
    if 'username' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    courses = read_courses()
    return render_template('admin_dashboard.html', courses=courses)

# ➕ افزودن دوره

@app.route('/admin/add_course', methods=['GET', 'POST'])
def add_course():
    if 'username' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        schedule = request.form.getlist('schedule')  # انتخاب چند روز/ساعت
        prerequisite = request.form['prerequisite'].strip() or None
        capacity = int(request.form['capacity'])
        description = request.form['description'].strip()

        courses = read_courses()
        new_course = Course(name, schedule, prerequisite, capacity, description)
        courses.append(new_course)
        save_courses(courses)

        flash("✅ دوره اضافه شد.", "success")
        return redirect(url_for('admin_dashboard'))

    return render_template('add_course.html')

# ✏️ ویرایش دوره
@app.route('/admin/edit_course/<course_id>', methods=['GET', 'POST'])
def edit_course(course_id):
    if 'username' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))

    courses = read_courses()
    course = next((c for c in courses if c.id == course_id), None)
    if not course:
        return "❌ دوره پیدا نشد."

    if request.method == 'POST':
        course.name = request.form['name']
        course.schedule = request.form.getlist('schedule')
        course.prerequisite = request.form['prerequisite'].strip() or None
        course.capacity = int(request.form['capacity'])
        course.description = request.form['description'].strip()
        save_courses(courses)

        flash("✅ دوره ویرایش شد.", "success")
        return redirect(url_for('admin_dashboard'))

    return render_template('edit_course.html', course=course)

# 🗑️ حذف دوره
@app.route('/admin/delete_course/<course_id>')
def delete_course(course_id):
    if 'username' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    courses = read_courses()
    courses = [c for c in courses if c.id != course_id]
    save_courses(courses)
    flash("✅ دوره حذف شد.", "success")
    return redirect(url_for('admin_dashboard'))

# 📜 مشاهده ثبت‌نام‌ها
@app.route('/admin/enrollments')
def admin_enrollments():
    if 'username' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))

    courses = read_courses()
    student_courses = read_student_courses()
    users = read_users()

    enrollments = []
    for sc in student_courses:
        user = next((u for u in users if u.username == sc['username']), None)
        course = next((c for c in courses if c.id == sc['course_id']), None)
        if user and course:
            enrollments.append({'student': user.username, 'course': course.name})
    return render_template('view_enrollments.html', enrollments=enrollments)

# -------------------------------
# 🎓 داشبورد دانشجو
# -------------------------------
@app.route('/student/dashboard')
def student_dashboard():
    if 'username' not in session or session['role'] != 'student':
        return redirect(url_for('login'))

    username = session['username']
    courses = read_courses()
    student_courses_data = read_student_courses()
    student_courses = [c for c in courses if any(sc['username'] == username and sc['course_id'] == c.id for sc in student_courses_data)]

    return render_template('student_dashboard.html', courses=courses, student_courses=student_courses)

# -------------------------------
# 🛒 ثبت‌نام و صفحه پرداخت
# -------------------------------
@app.route('/student/enroll/<course_id>')
def enroll(course_id):
    if 'username' not in session or session['role'] != 'student':
        return redirect(url_for('login'))

    username = session['username']
    courses = read_courses()
    student_courses = read_student_courses()

    course = next((c for c in courses if c.id == course_id), None)
    if not course:
        flash("❌ دوره یافت نشد.", "error")
        return redirect(url_for('student_dashboard'))

    # جلوگیری از ثبت‌نام تکراری
    if any(sc['username'] == username and sc['course_id'] == course_id for sc in student_courses):
        flash("⚠️ شما قبلاً این دوره را گرفته‌اید.", "error")
        return redirect(url_for('student_dashboard'))

    # چک ظرفیت
    enrolled_count = sum(1 for sc in student_courses if sc['course_id'] == course_id)
    if enrolled_count >= course.capacity:
        flash("⚠️ ظرفیت دوره پر است.", "error")
        return redirect(url_for('student_dashboard'))

    # چک پیش‌نیاز
    if course.prerequisite:
        has_prereq = any(
            c.name == course.prerequisite and sc['username'] == username and c.id == sc['course_id']
            for c in courses for sc in student_courses
        )
        if not has_prereq:
            flash(f"⚠️ پیش‌نیاز ({course.prerequisite}) را نگذرانده‌اید.", "error")
            return redirect(url_for('student_dashboard'))

    # چک تداخل زمانی
    enrolled_courses = [c for c in courses if any(sc['course_id'] == c.id and sc['username'] == username for sc in student_courses)]
    for ec in enrolled_courses:
        overlap = set(ec.schedule) & set(course.schedule)
        if overlap:
            flash(f"⚠️ تداخل زمانی با «{ec.name}» در {', '.join(overlap)}.", "error")
            return redirect(url_for('student_dashboard'))

    # اگر همه چیز اوکی بود → رفتن به پرداخت
    session['pending_course'] = course_id
    return redirect(url_for('checkout'))


@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if 'username' not in session or session.get('role') != 'student':
        return redirect(url_for('login'))

    course_id = session.get('pending_course')
    if not course_id:
        flash("هیچ دوره‌ای برای پرداخت انتخاب نشده.", "error")
        return redirect(url_for('student_dashboard'))

    courses = read_courses()
    course = next((c for c in courses if c.id == course_id), None)
    if not course:
        flash("دوره پیدا نشد.", "error")
        return redirect(url_for('student_dashboard'))

    if request.method == 'POST':
        if request.form.get('action') == 'pay':
            student_courses = read_student_courses()
            student_courses.append({'username': session['username'], 'course_id': course_id})
            save_student_courses(student_courses)

            course.capacity -= 1
            save_courses(courses)

            session.pop('pending_course', None)
            flash(f"✅ پرداخت موفق بود. دوره «{course.name}» ثبت شد.", "success")
            return redirect(url_for('student_dashboard'))
        else:
            session.pop('pending_course', None)
            flash("❌ پرداخت لغو شد.", "error")
            return redirect(url_for('student_dashboard'))

    return render_template('checkout.html', course=course)

# -------------------------------
# ❌ لغو ثبت‌نام
# -------------------------------
@app.route('/student/unenroll/<course_id>')
def unenroll(course_id):
    if 'username' not in session or session.get('role') != 'student':
        return redirect(url_for('login'))

    username = session['username']
    student_courses = read_student_courses()
    courses = read_courses()

    student_courses = [sc for sc in student_courses if not (sc['username'] == username and sc['course_id'] == course_id)]
    save_student_courses(student_courses)

    for c in courses:
        if c.id == course_id:
            c.capacity += 1
            break
    save_courses(courses)

    flash("ثبت‌نام شما از این دوره حذف شد.", "success")
    return redirect(url_for('student_dashboard'))

# -------------------------------
# 🚪 خروج
# -------------------------------
@app.route('/logout')
def logout():
    session.clear()
    flash("✅ با موفقیت خارج شدید.", "success")
    return redirect(url_for('login'))

# -------------------------------
# اجرای برنامه
# -------------------------------
if __name__ == '__main__':
    app.run(debug=True)