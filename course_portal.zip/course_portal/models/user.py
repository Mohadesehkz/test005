import uuid

class User:
    """
    کلاس کاربر برای مدیریت ثبت‌نام و ورود
    """

    def __init__(self, username, password, role):
        self.id = str(uuid.uuid4())  # آی‌دی یکتا
        self.username = username
        self.password = password
        self.role = role  # نقش (مدیر یا دانشجو)

    def to_dict(self):
        """تبدیل آبجکت کاربر به دیکشنری برای ذخیره در JSON"""
        return {
            'id': self.id,
            'username': self.username,
            'password': self.password,
            'role': self.role
        }

    @classmethod
    def from_dict(cls, data):
        """ساخت کاربر از دیکشنری (خواندن از JSON)"""
        obj = cls(data['username'], data['password'], data['role'])
        obj.id = data.get('id', str(uuid.uuid4()))
        return obj