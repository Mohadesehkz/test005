import uuid

class Course:
    def __init__(self, name, schedule, prerequisite=None, capacity=30, description="", id=None):
        # اگر ID داده نشده بود، یکی جدید می‌سازیم
        self.id = id if id else str(uuid.uuid4())
        self.name = name
        self.schedule = schedule          # برنامه (روز/ساعت)
        self.prerequisite = prerequisite  # پیش‌نیاز
        self.capacity = capacity          # ظرفیت
        self.description = description    # توضیحات دوره

    # تبدیل شیء به دیکشنری برای ذخیره در JSON
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'schedule': self.schedule,
            'prerequisite': self.prerequisite,
            'capacity': self.capacity,
            'description': self.description
        }

    # ساخت شیء از دیکشنری
    @classmethod
    def from_dict(cls, data):
        return cls(
            id=data.get('id'),
            name=data.get('name'),
            schedule=data.get('schedule'),
            prerequisite=data.get('prerequisite'),
            capacity=data.get('capacity', 30),
            description=data.get('description', "")
        )