import uuid

class Course:
    def __init__(self, name, schedule, prerequisite=None, capacity=30, description="", id=None):
        self.id = id if id else str(uuid.uuid4())
        self.name = name
        self.schedule = schedule          
        self.prerequisite = prerequisite  
        self.capacity = capacity          
        self.description = description    

    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'schedule': self.schedule,
            'prerequisite': self.prerequisite,
            'capacity': self.capacity,
            'description': self.description
        }

    
    @classmethod
    def from_dict(cls, data):
        return cls(
            id=data.get('id'),
            name=data.get('name'),
            schedule=data.get('schedule'),
            prerequisite=data.get('prerequisite'),
            capacity=data.get('capacity', 30),
            description=data.get('description', "")
        )